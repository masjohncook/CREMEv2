int 	parsedef(char *);
char	parseout(time_t, int, struct sstat *, struct pstat *,
			int, int, int, int, int, int, int, char);
